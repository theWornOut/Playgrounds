import UIKit

//ARRAY
//as > casting
//any > object
var myArray=["Metallica","Pentagram","Pantera",3,true] as [Any]
myArray[1]
myArray[4]
myArray[2]

var myStringArray=["Istanbul","Ankara","Izmir"]
myStringArray[0].uppercased()
myStringArray.count
myStringArray[myStringArray.count-2]
myStringArray.last
myStringArray.sort()

var myIntArray=[4,3,1,7,8,0,2]
myIntArray[2]
myIntArray.append(99)
myIntArray.last
myIntArray[3]=77

//SET
//Unordered Collection
//Unique elements
var mySet:Set=[2,3,5,1,4,6,8,1]
var myStringSet:Set=["a","b","c","a"]

var myInternetArray=[1,2,3,1,4,5,6,1,2]
var myInternetSet=Set(myInternetArray)
print(myInternetArray)
print(myInternetSet)

var mySet1:Set=[1,2,3]
var mySet2:Set=[3,4,5]
var mySet3=mySet1.union(mySet2)
print(mySet3)

//DICTIONARY
//key-value pairing
var dict=["TR":"Galatasaray","DE":"Bayern Munich","ESP":"Real Madrid"]
dict["TR"]
dict["ESP"]="Barcelona"
print(dict)
dict["FR"]="Paris Saint Germen"
print(dict)

var dict2=[0:"Run",1:"Football",2:"Basketball"]
dict2[3]="Swimming"
print(dict2)

var dict3=[["Lorem":50,"Ipsum":70],["Lorem2":90,"Ipsum2":10]]
print(dict3[1]["Lorem2"]!)
//Dictionaries can also be contained within Arrays.
