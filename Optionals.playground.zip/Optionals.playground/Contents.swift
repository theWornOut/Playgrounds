import UIKit

//OPTIONALS > ? vs !
//? nullable
//! not null

var greeting = "Hello, playground"
var name:String?
name?.uppercased()

var age = "q"
var myInt = (Int(age) ?? 0)*9

if let number = Int(age){
    print(number*5)
}
else{
    print("Wrong input!")
}
