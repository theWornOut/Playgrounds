import UIKit

/*
    Comparisons (==, !=, <, >, <=, >=)
    Logical Operators (!, &&, ||)
    Ranges (1...5 or 1..<5)
 */

// Aritmetic (+,-,/,*)
var usingMath = 4 + (5-3) / 3*1

// Compound assignments (+=, -=, /=, %=)
var currentAge = 31
currentAge *= 5

// Module (%)
var expOverflow = 100 % 98

var age = 31
if age < 30{
    print("30 -")
}
else if age > 30 && age < 40{
    print("30's")
}
else if age > 40 && age < 50{
    print("40's")
}
else{
    print("50 +")
}

3 < 5 && 9 < 7
3 < 5 || 9 < 7

var str = "James"
if str == "James"{
    print("Yeah!")
}
