import UIKit

//Input & Output & Return
func myFunc(){
    print("my func")
}
print("Hello world")
myFunc()

func sumFunc(x: Int, y: Int) -> Int{
    return x+y
}
sumFunc(x: 5, y: 99)
var result = sumFunc(x: 13, y: 24)
print(result)

func logicFunc(a:Int, b:Int) -> Bool{
    if a > b{
        return true
    }
    else{
        return false
    }
}
logicFunc(a: 99, b: 9)
