import UIKit

//Class Definition
var str:String="Variables exp"
var number:Int=10
var strNumber:String=String(50)

//define - not initialized
let myVar:String

//initialized
myVar="Test"
let myUpperVar = myVar.uppercased()
print(myUpperVar)
print(myVar)
